# w0 and w1 from Homework 2
w_0_mse = 11.259
w_1_mse = 0.180

w_0_abs = 1.7746000000000444
w_1_abs = 4.015744499999941


y_pred_mse = w_0_mse + w_1_mse * x
y_pred_abs = w_0_abs + w_1_abs * x


plt.figure(figsize=(12, 10))
plt.plot(x, y_pred_mse, color='red', label='MSE')
plt.plot(x, y_pred_abs, color='blue', label='MAE')
plt.plot(x, y, marker='.', linestyle='none', color='green', label='data')
plt.title('Linear regression with MSE and MAE')
plt.legend()
plt.show()