import numpy as np
import matplotlib.pyplot as plt


def gradient_descent(gradient, x, y, w0, w1, learning_rate=0.0001, 
                     threshold=1e-4, max_iter=1000):
    count = 0
    while True:
        grad = gradient(x, y, w0, w1)
        w0_new = w0 - learning_rate * grad[0]
        w1_new = w1 - learning_rate * grad[1]
        if abs(w1_new - w1) < threshold and abs(w0_new - w0) < threshold:
            break
        w0, w1 = w0_new, w1_new
        if count > max_iter:
            print(count)

            break
        count += 1
    return w1, w0


def d_abs_loss(x, y, w_0, w_1):
    y_pred = w_0 + w_1 * x
    grad_w_0 = np.sign(y_pred - y).mean()
    grad_w_1 = (np.sign(y_pred - y) * x).mean()
    return grad_w_0, grad_w_1


data = np.loadtxt('data.csv', delimiter=',')
x = data[:, 0]
y = data[:, 1]

# init weights randomly
w_0 = 0
w_1 = 0

new_w_1, new_w_0 = gradient_descent(d_abs_loss, x, y, w_1, w_0, max_iter=1000000)

print("Final weights:")
print("w_0 =", new_w_0)
print("w_1 =", new_w_1)
