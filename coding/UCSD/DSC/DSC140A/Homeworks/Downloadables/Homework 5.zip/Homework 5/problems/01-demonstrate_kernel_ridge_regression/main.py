from sklearn.linear_model import Ridge
import numpy as np
import math


def phi(x1, x2):
    return np.array([1, x1**2, x2**2, math.sqrt(2)*x1, math.sqrt(2)*x2, math.sqrt(2)*x1*x2])


X = np.array([
    [0, 2],
    [1, 0],
    [0, -2],
    [-1, 0],
    [0, 0]
])
y = [1, 1, 1, 1, -1]

phi_x = np.array([phi(x1, x2) for x1, x2 in X])


n, m = phi_x.shape
I = np.identity(m)
w = np.linalg.solve(phi_x.T @ phi_x + n*2*I, phi_x.T @ y)
# a
print(np.round(w, 3))

new_x = np.array([1, 1])
phi_new_x = phi(new_x[0], new_x[1])
# b
print(np.round(w @ phi_new_x, 3))

def kernel_func(x, x_prime):
    return (1 + np.dot(x, x_prime))**2


K = np.array([[kernel_func(x, x_prime) for x_prime in X] for x in X])
# c
print(K)

lambda_ = 2 * len(X)
alpha = np.linalg.solve(K + lambda_ * np.identity(len(X)), y)
# d
print(np.round(alpha, 3))

H2 = alpha @ np.array([kernel_func(new_x, x) for x in X]) 
# e
print(H2)