import numpy as np
import pandas as pd

# data
df = pd.DataFrame({
    'Temperature': [65, 72, 79, 55, 62, 71, 73],
    'Pressure': [1001, 1003, 1030, 1022, 1025, 1010, 1011],
    'Rain?': ['Yes', 'Yes', "No", 'Yes', 'No', 'Yes', 'No']
})\

def cal_gini(df):
    """
        Given split data, calculate the gini index
    """
    yes_count = (df['Rain?'] == 'Yes').sum()
    no_count = (df['Rain?'] == 'No').sum()
    if yes_count == 0 and no_count == 0:
        return 0
    yes_p = yes_count/len(df)
    return 2*yes_p*(1-yes_p)

def split_data(df, feature, value):
    """
        Given a feature and value, split the data into two groups
    """
    left = df[df[feature] < value]
    right = df[df[feature] >= value]
    return left, right

######################################################
# Root node split
######################################################
# Get the gini index for the original data for all possible splits
temp_values = df['Temperature'].unique()
pressure_values = df['Pressure'].unique()

gini_dict = {}

for temp in temp_values:
    left, right = split_data(df, 'Temperature', temp)
    gini_left = cal_gini(left)
    gini_right = cal_gini(right)
    gini_dict[temp] = (left.shape[0]/df.shape[0])*gini_left + (right.shape[0]/df.shape[0])*gini_right

for pressure in pressure_values:
    left, right = split_data(df, 'Pressure', pressure)
    gini_left = cal_gini(left)
    gini_right = cal_gini(right)
    gini_dict[pressure] = (left.shape[0]/df.shape[0])*gini_left + (right.shape[0]/df.shape[0])*gini_right

# Find the best split for root node
best_split = min(gini_dict, key=gini_dict.get)
x = 'Temperature' if best_split in temp_values else 'Pressure'
print(f"Best split is {x} <", best_split, "with gini index", gini_dict[best_split])

######################################################
# Left node split
######################################################
left_data_layer_1 = df[df[x] < best_split]
right_data_layer_1 = df[df[x] >= best_split]

# Calculate the gini index for the left 
left_temp_values = left_data_layer_1['Temperature'].unique()
left_pressure_values = left_data_layer_1['Pressure'].unique()

left_gini_dict_layer_1 = {}

for temp in left_temp_values:
    left, right = split_data(left_data_layer_1, 'Temperature', temp)
    gini_left = cal_gini(left)
    gini_right = cal_gini(right)
    left_gini_dict_layer_1[temp] = (left.shape[0]/left_data_layer_1.shape[0])*gini_left + (right.shape[0]/left_data_layer_1.shape[0])*gini_right

for pressure in left_pressure_values:
    left, right = split_data(left_data_layer_1, 'Pressure', pressure)
    gini_left = cal_gini(left)
    gini_right = cal_gini(right)
    left_gini_dict_layer_1[pressure] = (left.shape[0]/left_data_layer_1.shape[0])*gini_left + (right.shape[0]/left_data_layer_1.shape[0])*gini_right

# Find the best split for left node
best_split_left_layer_1 = min(left_gini_dict_layer_1, key=left_gini_dict_layer_1.get)
x = 'Temperature' if best_split_left_layer_1 in left_temp_values else 'Pressure'
print(f"Best split for left layer 1 is {x} <", best_split_left_layer_1, "with gini index", left_gini_dict_layer_1[best_split_left_layer_1])

######################################################
# Right node split
######################################################
right_temp_values = right_data_layer_1['Temperature'].unique()
right_pressure_values = right_data_layer_1['Pressure'].unique()

right_gini_dict_layer_1 = {}

for temp in right_temp_values:
    left, right = split_data(right_data_layer_1, 'Temperature', temp)
    gini_left = cal_gini(left)
    gini_right = cal_gini(right)
    right_gini_dict_layer_1[temp] = (left.shape[0]/right_data_layer_1.shape[0])*gini_left + (right.shape[0]/right_data_layer_1.shape[0])*gini_right

for pressure in right_pressure_values:
    left, right = split_data(right_data_layer_1, 'Pressure', pressure)
    gini_left = cal_gini(left)
    gini_right = cal_gini(right)
    right_gini_dict_layer_1[pressure] = (left.shape[0]/right_data_layer_1.shape[0])*gini_left + (right.shape[0]/right_data_layer_1.shape[0])*gini_right

best_split_right_layer_1 = min(right_gini_dict_layer_1, key=right_gini_dict_layer_1.get)
x = 'Temperature' if best_split_right_layer_1 in right_temp_values else 'Pressure'
print(f"Best split for right layer 1 is {x} <", best_split_right_layer_1, "with gini index", right_gini_dict_layer_1[best_split_right_layer_1])