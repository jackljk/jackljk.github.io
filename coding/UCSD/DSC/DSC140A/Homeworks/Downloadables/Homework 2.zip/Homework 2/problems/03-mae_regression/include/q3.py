import numpy as np
import matplotlib.pyplot as plt

data = np.loadtxt('data.csv', delimiter=',')

data = np.c_[np.ones(data.shape[0]), data]

w0, w1 =  np.linalg.lstsq(data[:,[0,1]], data[:,2])[0]

print('w0 = {}, w1 = {}'.format(w0, w1))