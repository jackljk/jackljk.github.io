import numpy as np
import matplotlib.pyplot as plt

dimensions = [2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]

min_dist = []
max_dist = []

for d in dimensions:
    data = np.random.uniform(-1, 1, (1000, d))
    
    dist = np.linalg.norm(data, axis=1)
    
    min_dist.append(np.min(dist))
    max_dist.append(np.max(dist))
    
plt.figure(figsize=(10, 5))
plt.plot(dimensions, min_dist, label='min', marker='o', color='r')
plt.xlabel('dimensions')
plt.ylabel('min distance')
plt.title('Minimum Distance from Origin, for Different Dimensions')
plt.grid()
plt.show()