import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression


data = np.loadtxt('data.csv', delimiter=',')
data = data[data[:, 0].argsort()]

x = data[:, 0]
y = data[:, 1]


mus = np.linspace(-10, 10, 50)
sigma = 1

gaussians = []
for mu in mus:
    gaussians.append(np.exp(-0.5 * (x - mu)**2 / sigma**2))


np.random.seed(0) # set the random seed for reproducibility

model = LinearRegression()
model.fit(np.array(gaussians).T, y)


print(model.coef_[0])