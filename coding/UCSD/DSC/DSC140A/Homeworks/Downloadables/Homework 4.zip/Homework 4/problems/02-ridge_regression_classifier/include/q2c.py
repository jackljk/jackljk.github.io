from sklearn.linear_model import Ridge


np.random.seed(0)
model = Ridge(alpha=0.1)
model.fit(np.array(gaussians).T, y)

hx_ridge = model.predict(np.array(gaussians).T)

# Plot the original data
plt.scatter(x, y)

# Plot H(x) using Ridge on top of the original data
plt.plot(x, hx_ridge, color='red')

# Show the plot
plt.xlabel('x')
plt.ylabel('y')
plt.title('Gaussian Basis Function Regression with Ridge regularization')
plt.legend(['Original data', 'H(x) with Ridge'])
plt.show()