# Calculate H(x) using the trained model
hx = model.predict(np.array(gaussians).T)

# Plot the original data
plt.scatter(x, y)

# Plot H(x) on top of the original data
plt.plot(x, hx, color='red')


plt.xlabel('x')
plt.ylabel('y')
plt.title('Gaussian Basis Function Regression with no regularization')
plt.legend(['Original data', 'H(x)'])
plt.show()