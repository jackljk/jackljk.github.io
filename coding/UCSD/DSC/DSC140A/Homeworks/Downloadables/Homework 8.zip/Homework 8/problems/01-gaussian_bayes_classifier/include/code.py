import numpy as np

data = np.loadtxt('data.csv', delimiter=',')
X = data[:, :2]
y = data[:, 2]

class_1 = X[y == 1]
class_neg1 = X[y == -1]

mu_1 = np.mean(class_1, axis=0)
mu_neg1 = np.mean(class_neg1, axis=0)

def cov(X, mu):
    n = X.shape[0]
    return (X - mu).T @ (X - mu) / n

cov_1 = cov(class_1, mu_1)
cov_neg1 = cov(class_neg1, mu_neg1)

print(
    f'Mean for class 1: {mu_1}\n'
    f'Mean for class -1: {mu_neg1}\n'
    f'Covariance for class 1: \n{cov_1}\n'
    f'Covariance for class -1:\n {cov_neg1}'
)

x_news = np.array([
    [0, 0],
    [1, 1],
    [10, 5],
    [5, -5],
    [8, 5]
])

def predict(x_new, mu_1, mu_2, cov_1, cov_2):
    d_1 = (x_new - mu_1) @ np.linalg.inv(cov_1) @ (x_new - mu_1).T
    d_2 = (x_new - mu_2) @ np.linalg.inv(cov_2) @ (x_new - mu_2).T
    return 1 if d_1 < d_2 else -1

for x in x_news:
    pred = predict(x, mu_1, mu_neg1, cov_1, cov_neg1)
    print(f'Prediction for {x}: {pred}')