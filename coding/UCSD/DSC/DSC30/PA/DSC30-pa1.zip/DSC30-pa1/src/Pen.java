public class Pen {
    String color;

    public Pen() {
        color = "black";
    }

    public Pen(String myColor) {
        color = myColor;
    }

    public void changeColor(String color) {
        System.out.println(color);
        System.out.println(this.color);
        this.color = color;
    }

    public static void main(String[] args) {
        Pen pen1 = new Pen("blue");
        System.out.println(pen1.color);

        Pen pen2 = new Pen();
        System.out.println(pen2.color);

        pen2.changeColor("purple");
        System.out.println(pen1.color);
    }
}