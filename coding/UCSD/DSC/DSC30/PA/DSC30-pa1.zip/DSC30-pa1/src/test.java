import javax.sound.midi.SysexMessage;
import java.util.Arrays;

public class test {
    int a = 1;
    int b = 2;
    public static void discussion(int a, int b) {
        for (int i = 0; i < a; i++) {
            System.out.println("quizzes are fun!");
        }
        int j = 0;
        while (j < 4) {
            System.out.println("or maybe not");
            j += 1;
        }
    }
    public static void main(String[] arg) {
        int[] arr = {1, 2, 4, 8, 9, 10};
        int[] reversed = ProgrammingChallenges.reverseEvenNumber(arr);
        System.out.println(Arrays.toString(arr));
        System.out.println(Arrays.toString(reversed));
        String s = "DSC_is_Fun";
        System.out.println(Arrays.toString(s.toCharArray()));
        System.out.println(ProgrammingChallenges.checkPasswordStrength(s));
        double[] x = {0, 3, 0, 4};
        double[] y = {0, 0, 4, 4};
        System.out.println(Arrays.toString(ProgrammingChallenges.findShortestDistance(x,  y)));
        String[] arr2 =  {"BMW", "BMW", "Toyota", "Toyota", "BMW", "Honda", "BMW"};
        System.out.println(Arrays.toString(ProgrammingChallenges.getUnique(arr2)));
        int[][] test = ProgrammingChallenges.oneHotEncode(arr2);
        for (int i = 0;i<3;i++){
            System.out.println(Arrays.toString(test[i]));
        }
        int[] poly1 = {5, 5, 4};
        int[] poly2 = {0, 3, 4};
        System.out.println(Arrays.toString(ProgrammingChallenges.calculateDerivative(poly2)));
        System.out.print(ProgrammingChallenges.getIntersection(poly1, poly2));
    }

}
