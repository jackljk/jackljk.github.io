import org.junit.Before;
import org.junit.Test;

import java.util.EmptyStackException;

import static org.junit.Assert.*;

public class IntStackTest {
    private IntStack a;
    private IntStack b;
    private IntStack c;


    @Before
    public void setUp() throws Exception {
        a = new IntStack(10);
        b = new IntStack(5, 0.9);
        c = new IntStack(5, 0.9, 0.1);
    }

    @Test
    public void isEmpty() {
        assertTrue(a.isEmpty());
        a.push(10);
        assertFalse(a.isEmpty());
        assertTrue(b.isEmpty());
    }

    @Test
    public void size() {
        assertEquals(0, a.size());
        a.push(10);
        a.push(10);
        assertEquals(2, a.size());
        assertEquals(0, b.size());
    }

    @Test
    public void capacity() {
        assertEquals(10, a.capacity());
        assertEquals(5, b.capacity());
        assertEquals(5, c.capacity());
    }

    @Test
    public void pushPeek() {
        a.push(10);
        assertEquals(10, a.peek());
        for (int i = 0;i<100;i++){
            b.push(i);
        }
        assertEquals(100, b.size());
        assertEquals(99, b.peek());
        assertEquals(10, a.peek());
        a.push(100000);
        assertEquals(100000, a.peek());
    }

    @Test
    public void pop() {
        for (int i = 0;i<100;i++){
            a.push(i);
        }
        assertEquals(100, a.size());
        assertEquals(99, a.pop());
        assertEquals(99, a.size());
        a.pop();
        a.pop();
        a.pop();
        a.pop();
        assertEquals(95, a.size());
        assertEquals(94, a.peek());
        assertEquals(94, a.pop());
    }

    @Test
    public void multiPushClear() {
        int[] testa = new int[]{1, 2, 3, 4, 5, 6, 7,  8, 9, 10};
        a.multiPush(testa);
        assertEquals(10, a.peek());
        assertEquals(20, a.capacity());
        assertEquals(10, a.size());
        a.clear();
        assertEquals(0, a.size());
        assertEquals(10, a.capacity());
        int[] testb = new int[]{1, 2, 3, 4, 5, 6, 7,  8, 9};
        b.multiPush(testb);
        assertEquals(9, b.size());
        assertEquals(9, b.peek());
        assertEquals(10, b.capacity());
        b.multiPush(testb);
        assertEquals(20, b.capacity());
        b.clear();
        assertEquals(5, b.capacity());
        assertEquals(0, b.size());
        int[] testc = new int[]{1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1
                , 2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6,
                7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1,
                2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,
                8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10};
        c.multiPush(testc);
        assertEquals(110, c.size());
        assertEquals(160, c.capacity());
        assertEquals(10, c.peek());
        c.clear();
        assertEquals(0, c.size());
        assertEquals(5, c.capacity());
    }

    @Test
    public void multiPop() {
        int[] testa = new int[]{1, 2, 3, 4, 5, 6, 7,  8, 9, 10};
        int[] ansa = new int[]{10, 9, 8, 7};
        a.multiPush(testa);
        assertArrayEquals(ansa, a.multiPop(4));
        assertEquals(6, a.size());
        int[] testb = new int[]{1, 2, 3, 4, 5, 6, 7,  8, 9, 10};
        b.multiPush(testb);
        assertEquals(20, b.capacity());
        b.multiPop(7);
        assertEquals(10, b.capacity());
        b.pop();
        assertEquals(5, b.capacity());
        int[] testc = new int[]{1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1
                , 2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6,
                7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1,
                2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10, 1, 2, 3, 4, 5, 6, 7,
                8, 9, 10, 1, 2, 3, 4, 5, 6, 7,  8, 9, 10};
        c.multiPush(testc);
        c.multiPop(100);
        assertEquals(10, c.size());
        assertEquals(80, c.capacity());
        c.multiPop(5);
        assertEquals(40, c.capacity());
        c.multiPop(4);
        assertEquals(10, c.capacity());
    }

    @Test (expected = IllegalArgumentException.class)
    public void constructorIAE1(){
        IntStack test = new IntStack(3);
    }

    @Test (expected = IllegalArgumentException.class)
    public void constructorIAE2(){
        IntStack test = new IntStack(10, 0.5);
    }

    @Test (expected = IllegalArgumentException.class)
    public void constructorIAE3(){
        IntStack test = new IntStack(10, 0.75, 0.5);
    }

    @Test (expected = EmptyStackException.class)
    public void peekESE(){
        a.peek();
    }

    @Test (expected = EmptyStackException.class)
    public void popESE(){
        a.pop();
    }

    @Test(expected = IllegalArgumentException.class)
    public void mutlipushIAE(){
        a.multiPush(null);
    }

    @Test (expected = IllegalArgumentException.class)
    public void multipopIAE(){
        a.multiPop(-10);
    }
}
