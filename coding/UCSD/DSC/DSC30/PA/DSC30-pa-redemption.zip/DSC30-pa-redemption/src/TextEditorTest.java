import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class TextEditorTest {
    TextEditor te;
    TextEditor te2;
    @Before
    public void makeEditor(){
        te = new TextEditor();
        te2 = new TextEditor();
    }

    @Test
    public void getText() {
        te.insert(0, "hi");
        assertTrue("hi".equals(te.getText()));
        te.insert(2, " there");
        assertTrue("hi there".equals(te.getText()));
        te.insert(2, " :)");
        assertTrue("hi :) there".equals(te.getText()));
    }

    @Test
    public void length() {
        te.insert(0, "hi");
        assertEquals(2, te.length());
        te.insert(2, " there");
        assertEquals(8, te.length());
        te.insert(2, " :)");
        assertEquals(11, te.length());
    }

    @Test
    public void caseConvert() {
        te.insert(0, "hi");
        te.caseConvert(0, 1);
        assertTrue("Hi".equals(te.getText()));
        te.insert(2, " there");
        te.caseConvert(4,7);
        assertTrue("Hi tHERe".equals(te.getText()));
        te.insert(2, " :)");
        te.caseConvert(0, 11);
        assertTrue("hI :) TherE".equals(te.getText()));
    }

    @Test
    public void insert() {
        te.insert(0, "hi");
        assertTrue("hi".equals(te.getText()));
        te.insert(2, " there");
        assertTrue("hi there".equals(te.getText()));
        te.insert(2, " :)");
        assertTrue("hi :) there".equals(te.getText()));
    }

    @Test
    public void delete() {
        te.insert(0, "hi");
        assertTrue("hi".equals(te.getText()));
        te.insert(2, " there");
        assertTrue("hi there".equals(te.getText()));
        te.insert(2, " :)");
        assertTrue("hi :) there".equals(te.getText()));
        te.delete(2,5);
        assertTrue("hi there".equals(te.getText()));
        te.delete(2,3);
        assertTrue("hithere".equals(te.getText()));
        te.delete(0, 7);
        assertTrue("".equals(te.getText()));
    }

    @Test
    public void undo() {
        te.insert(0, "hi");
        te.caseConvert(0, 1);
        assertTrue("Hi".equals(te.getText()));
        te.insert(2, " there");
        te.caseConvert(4,7);
        assertTrue("Hi tHERe".equals(te.getText()));
        te.insert(2, " :)");
        te.caseConvert(0, 11);
        assertTrue("hI :) TherE".equals(te.getText()));
        assertTrue(te.undo());
        assertTrue("Hi :) tHERe".equals(te.getText()));
        assertFalse(te2.undo());
        assertTrue(te.undo());
        assertTrue("Hi tHERe".equals(te.getText()));
        te.delete(4,7);
        assertTrue("Hi te".equals(te.getText()));
        te.undo();
        assertTrue("Hi tHERe".equals(te.getText()));

    }

    @Test
    public void redo() {
        te.insert(0, "hi");
        te.caseConvert(0, 1);
        assertTrue("Hi".equals(te.getText()));
        assertFalse(te.redo());
        te.insert(2, " there");
        te.caseConvert(4,7);
        assertTrue("Hi tHERe".equals(te.getText()));
        te.insert(2, " :)");
        te.caseConvert(0, 11);
        assertTrue("hI :) TherE".equals(te.getText()));
        assertTrue(te.undo());
        assertTrue("Hi :) tHERe".equals(te.getText()));
        assertTrue(te.redo());
        assertTrue("hI :) TherE".equals(te.getText()));
        assertTrue(te.undo());
        assertTrue("Hi :) tHERe".equals(te.getText()));
        assertFalse(te2.redo());
        te.delete(2,5);
        assertTrue("Hi tHERe".equals(te.getText()));
        te.undo();
        te.redo();
        assertTrue("Hi tHERe".equals(te.getText()));
        te.insert(2, " :)");
        assertTrue("Hi :) tHERe".equals(te.getText()));
        te.undo();
        te.redo();
        assertTrue("Hi :) tHERe".equals(te.getText()));
        assertFalse(te.redo());

        te2.insert(0, "Hello there");
        te2.caseConvert(0, 5);
        assertTrue("hELLO there".equals(te2.getText()));
        te2.undo();
        te2.undo();
        assertTrue("".equals(te2.getText()));
        te2.redo();
        te2.redo();
        assertTrue("Hello there".equals(te2.getText()));
    }
    @Test(expected = IllegalArgumentException.class)
    public void testCaseEx() {
        te.insert(0, "hi");
        te.insert(2, " there");
        te.insert(2, " :)");
        te.caseConvert(-1,3);
        te.caseConvert(2, 25);
        te.caseConvert(3,2);
    }
    @Test(expected = NullPointerException.class)
    public void testInsertEx1() {
        te.insert(0, null);
    }
    @Test(expected = IllegalArgumentException.class)
    public void testInsertEx2() {
        te.insert(1, "hi");
    }
    @Test(expected = IllegalArgumentException.class)
    public void testDeleteEx() {
        te.insert(0, "hi");
        te.insert(2, " there");
        te.insert(2, " :)");
        te.delete(-2, 4);
        te.delete(2, 37);
        te.delete(4,2);
    }
}