/*
    Name: Jack Kai Lim
    PID:  A16919063
 */

/**
 * Weather Monitor Implementation
 * @author Jack Kai Lim
 * @since  05/30/2022
 */

public class WeatherMonitor {
    private final int STACK_CAPCACITY = 10;
    private final IntStack monitor;
    private final IntStack tempStore;

    /**
     * Constructor for the weather monitor instances
     */
    public WeatherMonitor() {
        /* Initializes the instance variables */
        this.monitor = new IntStack(STACK_CAPCACITY);
        this.tempStore = new IntStack(STACK_CAPCACITY);
    }

    /**
     * Counts the number of previous consecutive days that the current day is warmer than
     * @param temp Current temp
     * @return The number of days it is hotter than
     */
    public int numDays(int temp) {
       /* Counts the number of days */
        if (this.monitor.isEmpty()){
            this.monitor.push(temp);
            return 0;
        }
        int counter = 0;
        while (!this.monitor.isEmpty()){
            //Counts the number of days
            int popped = this.monitor.pop();
            if (temp > popped){//Hotter than
                this.tempStore.push(popped);
                counter++;
            } else {//Colder than so stop while loop
                this.tempStore.push(popped);
                break;
            }
        }
        while (!this.tempStore.isEmpty()){
            //Restore all values into main monitor stack
            this.monitor.push(this.tempStore.pop());
        }
        this.monitor.push(temp);
        return counter;
    }
    
}