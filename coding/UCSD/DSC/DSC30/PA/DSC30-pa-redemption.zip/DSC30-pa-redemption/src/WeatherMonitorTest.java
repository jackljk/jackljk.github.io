import org.junit.Test;

import static org.junit.Assert.*;

public class WeatherMonitorTest {

    @Test
    public void lol(){
        WeatherMonitor a = new WeatherMonitor();
        System.out.println(a.numDays(59));
        System.out.println(a.numDays(60));
        System.out.println(a.numDays(70));
        System.out.println(a.numDays(69));
        System.out.println(a.numDays(71));
        System.out.println(a.numDays(72));
        System.out.println(a.numDays(73));
        System.out.println(a.numDays(30));
        System.out.println(a.numDays(31));

    }

}