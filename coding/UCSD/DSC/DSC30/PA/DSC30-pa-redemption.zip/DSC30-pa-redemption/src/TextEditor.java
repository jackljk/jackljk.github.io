/*
    Name: Jack Kai Lim
    PID:  A16919063
 */

import java.util.Locale;

import static java.lang.Character.isUpperCase;

/**
 * Text Editor Implementation
 * @author Jack Kai Lim
 * @since  05/30/2022
 */
public class TextEditor {
    /* Final Variables */
    private final int CASE_CONVERT = 0;
    private final int INSERT = 1;
    private final int DELETE = 2;


    /* instance variables */
    private String text;
    private IntStack undo;
    private StringStack deletedText;
    private IntStack redo;
    private StringStack insertedText;

    /**
     * Constructor
     */
    public TextEditor() {
        /* Initializes the TextEditor */
        int BASE_CAPACITIES = 10;
        this.text = "";
        this.undo = new IntStack(BASE_CAPACITIES);
        this.deletedText = new StringStack(BASE_CAPACITIES);
        this.redo = new IntStack(BASE_CAPACITIES);
        this.insertedText = new StringStack(BASE_CAPACITIES);
    }

    /**
     * Getter Method
     * @return The text stored at the instance
     */
    public String getText() {
        /* Returns the text at it's current state. */
        return this.text;
    }

    /**
     * Getter Method
     * @return The length of the text at the instance
     */
    public int length() {
        /* Returns the length of the text at its current state. */
        return this.text.length();
    }

    /**
     * Changes the casing for values in the range below
     * @param i Start (Including)
     * @param j End (Excluding)
     */
    public void caseConvert(int i, int j) {
        /* Implementation for case convert */
        //Check Inputs
        if (i < 0 || j < 0 || i > j || i > this.length() || j > this.length()){
            throw new IllegalArgumentException();
        }
        //Push the Case Convert into undo stack
        this.undo.multiPush(new int[]{i, j, CASE_CONVERT});
        StringBuilder text  = new StringBuilder(this.text);
        for (int z = i;z<j;z++){
            if (Character.isUpperCase(this.text.charAt(z))){
                text.setCharAt(z, Character.toLowerCase(this.text.charAt(z)));
            } else {
                text.setCharAt(z, Character.toUpperCase(this.text.charAt(z)));
            }
        }
        this.text = text.toString();
    }

    /**
     * Adds a string input to the specified position
     * @param i position to add the string
     * @param input The string to add
     */
    public void insert(int i, String input) {
        /* Implementation of insert */
        //Check for input exceptions
        if (input == null) {
            throw new NullPointerException();
        }
        if (i < 0 || i > this.length()){
            throw new IllegalArgumentException();
        }
        //Inserting the string
        StringBuilder text = new StringBuilder(this.text);
        text.insert(i, input);
        //Adding to undo stack and inserted text stack
        this.undo.multiPush(new int[]{i, i + input.length(), INSERT});
        this.text = text.toString();
    }

    /**
     * Delete text from the specified index
     * @param i Start (Inclusive)
     * @param j End (Exclusive)
     */
    public void delete(int i, int j) {
        /* Delete Implementation */
        //Input Checks
        if (i < 0 || j < 0 || i > j || i > this.length() || j > this.length()){
            throw new IllegalArgumentException();
        }
        //Delete text and add to delete stack
        StringBuilder text = new StringBuilder(this.text);
        this.deletedText.push(text.substring(i, j));
        text.delete(i, j);
        //Add to Undo stack
        this.undo.multiPush(new int[]{i, j, DELETE});
        this.text = text.toString();
    }

    /**
     * Undoes the operations done in order
     * @return True is successfully undone, false otherwise
     */
    public boolean undo() {
        /* Undo Implementation */
        if (undo.isEmpty()){
            //If there is nothing to undo
            return false;
        }
        if (this.undo.peek() == CASE_CONVERT){
            //For case convert
            this.undo.pop();
            int j = this.undo.pop();
            int i = this.undo.pop();
            StringBuilder text  = new StringBuilder(this.text);
            for (int z = i;z<j;z++){
                if (Character.isUpperCase(this.text.charAt(z))){
                    text.setCharAt(z, Character.toLowerCase(this.text.charAt(z)));
                } else {
                    text.setCharAt(z, Character.toUpperCase(this.text.charAt(z)));
                }
            }
            //Adds to redo stack
            this.redo.multiPush(new int[]{i, j, CASE_CONVERT});
            this.text = text.toString();
            return true;
        } else if (this.undo.peek() == INSERT){
            //For insert
            this.undo.pop();
            int j = this.undo.pop();
            int i = this.undo.pop();
            StringBuilder text = new StringBuilder(this.text);
            //Adding inserting text to inserted text stack for redo later
            this.insertedText.push(text.substring(i, j));
            //Deletes/Undoes the inserted text
            text.delete(i, j);
            //Add to the redo stack
            this.redo.multiPush(new int[]{i, j, INSERT});
            this.text = text.toString();
            return true;
        } else if (this.undo.peek() == DELETE){
            //For delete
            this.undo.pop();
            int j = this.undo.pop();
            int i = this.undo.pop();
            StringBuilder text = new StringBuilder(this.text);
            //Adds the deleted text which is got from the deleted stack
            text.insert(i, this.deletedText.pop());
            this.redo.multiPush(new int[]{i, j, DELETE});
            this.text = text.toString();
            return true;
        }
        return false;
    }

    /**
     * Redoes a undone action
     * @return True if successful, false otherwise.
     */
    public boolean redo() {
        /* Redo Implementation */
        if (this.redo.isEmpty()){
            return false;
        } else if (this.redo.peek() == CASE_CONVERT){
            this.redo.pop();
            int j = this.redo.pop();
            int i = this.redo.pop();
            this.caseConvert(i, j);
            return true;
        } else if (this.redo.peek() == INSERT){
            //For insert
            this.redo.pop();
            int j = this.redo.pop();
            int i = this.redo.pop();
            this.insert(i, this.insertedText.pop());
            return true;
        } else if (this.redo.peek() == DELETE){
            //For delete
            this.redo.pop();
            int j = this.redo.pop();
            int i = this.redo.pop();
            this.delete(i, j);
            return true;
        }
        return false;
    }
}