/*
    Name: Jack Kai Lim
    PID:  A16919063
 */

import java.util.EmptyStackException;

/**
 * Implementation of the String Stack
 * @author Jack Kai Lim
 * @since  A16919063
 */
public class StringStack {
    /* Final Variables */
    private final int MIN_CAPACITY = 5;
    private final double MIN_LOAD_FACTOR = 0.67;
    private final double MAX_SHRINK_FACTOR = 0.33;

    /* instance variables, feel free to add more if you need */
    private String[] data;
    private int nElems;
    private double loadFactor;
    private double shrinkFactor;
    private int initCap;

    /**
     * 3-arg constructor of an String Stack
     * @param capacity Capacity of the stack
     * @param loadF Load factor of the Stack
     * @param shrinkF Shrink factor of the Stack
     */
    public StringStack(int capacity, double loadF, double shrinkF) {
        /* Main constructor with 3 args */
        if (capacity < MIN_CAPACITY || loadF < MIN_LOAD_FACTOR|| loadF > 1 || shrinkF < 0
                || shrinkF > MAX_SHRINK_FACTOR){
            throw new IllegalArgumentException();
        }
        this.data = new String[capacity];
        this.initCap = capacity;
        this.nElems = 0;
        this.loadFactor = loadF;
        this.shrinkFactor = shrinkF;
    }

    /**
     * Constructor with default shrinkF
     * @param capacity Capacity of the stack
     * @param loadF Load factor of the stack
     */
    public StringStack(int capacity, double loadF) {
        /* 2-arg constructor  */
        this(capacity, loadF, 0.25);
    }

    /**
     * Constructor with default ShrinkF and LoadF
     * @param capacity Capacity of the stack
     */
    public StringStack(int capacity) {
        /* 1-arg constructor */
        this(capacity, 0.75, 0.25);
    }

    /**
     * Getter Method
     * @return True if stack is empty, false otherwise
     */
    public boolean isEmpty() {
        /* Checks if the stack is empty of not */
        return this.nElems == 0;
    }

    /**
     * Resets the stack
     */
    public void clear() {
        /* Creates a new array to reset the stack */
        this.data = new String[this.initCap];
        this.nElems = 0;
    }

    /**
     * Getter Methods
     * @return Current size of stack
     */
    public int size() {
        /* Returns the number of elements in the stack */
        return this.nElems;
    }

    /**
     * Getter Method
     * @return The capacity of the stack currently
     */
    public int capacity() {
        /* Returns the size of the data array */
        return this.data.length;
    }

    /**
     * Returns the element at the top of the stack
     * @return The element at the top of the stack
     */
    public String peek() {
        /* Returns the top element of the stack */
        if (isEmpty()){
            throw new EmptyStackException();
        } else {
            return this.data[this.nElems - 1];
        }
    }

    /**
     * Adds an element to the top of the stack
     * @param element Element to be adding
     */
    public void push(String element) {
        /* Adds an element to the top of the stack */
        int resizeFactor = 2;
        if ((double) this.size()/this.capacity() >= this.loadFactor){
            //Resizes than adds element to the top of the stack if the stack is more than the
            // load factor
            String[] temp = new String[this.capacity() * resizeFactor];
            System.arraycopy(this.data, 0, temp, 0, this.size());
            this.data = temp;
            //Adding new element to the top of the stack
            this.data[this.nElems] = element;
            this.nElems++;
        } else {
            //Adding new element to the top of the stack
            this.data[this.nElems] = element;
            this.nElems++;
        }

    }

    /**
     * Removes the element at the top of the list
     * @return The popped element
     */
    public String pop() {
        /* Pops the element at the top of the stack */
        if (isEmpty()){
            throw new EmptyStackException();
        }
        //Removes the element at the top of the stack
        int resizeFactor = 2;
        this.nElems--;
        String popped = this.data[this.nElems];
        this.data[this.nElems] = "";
        //Resizes if the stack is load factor is less than the shrink factor of the stack
        if ((double) this.size()/this.capacity() < this.shrinkFactor){
            if (this.capacity()/resizeFactor <= this.initCap){
                String[] temp = new String[this.initCap];
                System.arraycopy(this.data, 0,  temp, 0, this.size());
                this.data = temp;
            } else {
                String[] temp = new String[this.capacity()/resizeFactor];
                System.arraycopy(this.data, 0,  temp, 0, this.size());
                this.data = temp;
            }
        }
        return popped;
    }

    /**
     * Adds a number of elements into the stack
     * @param elements Elements to be added
     */
    public void multiPush(String[] elements) {
        /* Pushes all elements in the elements array to the stack */
        if (elements == null){
            throw new IllegalArgumentException();
        }
        for (String ele : elements){
            this.push(ele);
        }
    }

    /**
     * Removes a set number of elements from the stack
     * @param amount Number of elements to pop
     * @return Array of popped elements
     */
    public String[] multiPop(int amount) {
        /* Pops the amount stated */
        if (amount < 0){
            throw new IllegalArgumentException();
        }
        String[] popped = new String[amount];
        for (int i = 0;i<amount;i++){
            popped[i] = this.pop();
        }
        return popped;
    }
}