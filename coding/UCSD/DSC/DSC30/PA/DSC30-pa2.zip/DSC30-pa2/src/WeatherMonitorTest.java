import org.junit.Test;

import static org.junit.Assert.*;

public class WeatherMonitorTest {
    @Test
    public void test(){
        WeatherMonitor sm = new WeatherMonitor();
        assertEquals(0, sm.numDays(59));
        assertEquals(1, sm.numDays(60));
        assertEquals(2, sm.numDays(70));
        assertEquals(0, sm.numDays(10));
        assertEquals(4, sm.numDays(100));
    }
}