import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class TextEditorTest {
    private TextEditor a;
    private TextEditor b;
    private TextEditor c;

    @Before
    public void init(){
        a = new TextEditor();
        a.insert(0, "Test String");
        b = new TextEditor();
        b.insert(0, "Test StringOH YEA");
        c = new TextEditor();
        c.insert(0, "Test String");
    }

    @Test
    public void getText() {
        assertEquals("Test String", a.getText());
    }

    @Test
    public void length() {
        assertEquals(11, a.length());
    }

    @Test
    public void caseConvert() {
        a.caseConvert(1, 4);
        assertEquals("TEST String", a.getText());
        b.caseConvert(0,4);
        assertEquals("tEST StringOH YEA", b.getText());
    }

    @Test
    public void insert() {
        a.insert(0, "DSC30");
        assertEquals("DSC30Test String", a.getText());
        b.insert(4, "BABY");
        assertEquals("TestBABY StringOH YEA", b.getText());
        c.insert(c.length(), "TESTT");
        assertEquals("Test StringTESTT", c.getText());
    }

    @Test
    public void delete() {
        a.delete(0,4);
        assertEquals(" String", a.getText());
        b.delete(2, b.length());
        assertEquals("Te",  b.getText());
    }

    @Test
    public void undo() {
        a.insert(0, "DSC30");
        assertEquals("DSC30Test String", a.getText());
        a.delete(9, a.length());
        assertEquals("DSC30Test", a.getText());
        a.caseConvert(0, 3);
        assertEquals("dsc30Test", a.getText());
        a.undo();
        assertEquals("DSC30Test", a.getText());
        a.undo();
        assertEquals("DSC30Test String", a.getText());
        a.undo();
        assertEquals("Test String", a.getText());
    }

    @Test
    public void redo() {
        a.insert(0, "DSC30");
        assertEquals("DSC30Test String", a.getText());
        a.undo();
        assertEquals("Test String", a.getText());
        a.redo();
        assertEquals("DSC30Test String", a.getText());
        a.delete(0,5);
        assertEquals("Test String", a.getText());
        a.undo();
        assertEquals("DSC30Test String", a.getText());
        a.redo();
        assertEquals("Test String", a.getText());
        a.caseConvert(0, 4);
        assertEquals("tEST String", a.getText());
        a.undo();
        assertEquals("Test String", a.getText());
        a.redo();
        assertEquals("tEST String", a.getText());
        c.insert(0, "TEST");
        c.delete(0, 4);
        c.caseConvert(0, 4);
        assertEquals("tEST String", c.getText());
        c.undo();
        c.undo();
        c.undo();
        assertEquals("Test String", c.getText());
        c.redo();
        c.redo();
        c.redo();
        assertEquals("tEST String", c.getText());
    }

    @Test (expected = IllegalArgumentException.class)
    public void caseConvert_exceptions(){
        a.caseConvert(20, 30);
        a.caseConvert(1, 30);
        a.caseConvert(4, 1);
    }

    @Test (expected = NullPointerException.class)
    public void insert_exceptions_1(){
        a.insert(0, null);
    }
    @Test (expected = IllegalArgumentException.class)
    public void insert_exceptions_2(){
        a.insert(100, "HIII");
    }
    @Test (expected = IllegalArgumentException.class)
    public void delete_exception(){
        a.delete(20, 30);
        a.delete(1, 30);
        a.delete(4, 1);
    }
}